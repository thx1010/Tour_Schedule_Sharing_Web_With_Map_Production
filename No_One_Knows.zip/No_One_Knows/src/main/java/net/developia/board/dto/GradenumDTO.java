package net.developia.board.dto;

import lombok.*;

@Getter
@Setter
@ToString
public class GradenumDTO {
	private int grade_first;
	private int grade_second;
	private int grade_third;
}
