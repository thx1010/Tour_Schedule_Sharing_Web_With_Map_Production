package net.developia.board.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class ThemeDTO {
	long theme_no;
	String theme_name;
	String theme_content;
}
